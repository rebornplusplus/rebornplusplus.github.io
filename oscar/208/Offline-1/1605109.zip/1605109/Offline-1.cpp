// Dijkstra
// Rafid, 1605109
// Nov 11 2018 0041

#include <iostream>
#include <cassert>
using namespace std;

// MAX Heap Implementation
// Rafid, 1605109
// July 15 2018 0635

template <class T>
class max_heap {
	#define PARENT(i) (i>>1)
	#define LEFT(i) (i<<1)
	#define RIGHT(i) ((i<<1) | 1)

	static const int INF = 2000000000;
	static const int initial_sz = 2;
	int sz, len;
	T *a;

	void heapify(int i) {
		int l = LEFT(i);
		int r = RIGHT(i);
		int largest;
		if(l <= sz and a[i-1] < a[l-1]) largest = l;
		else largest = i;
		if(r <= sz and a[largest-1] < a[r-1]) largest = r;
		if(largest != i) {
			swap(a[i-1], a[largest-1]);
			heapify(largest);
		}
	}

	void build_max_heap() {
		for(int i=sz/2; i>=1; --i) {
			heapify(i);
		}
	}

	void increase_key(int i, T key) {
		if(key < a[i-1]) return ;
		a[i-1] = key;
		while(i > 1 and a[PARENT(i)-1] < a[i-1]) {
			swap(a[i-1], a[PARENT(i)-1]);
			i = PARENT(i);
		}
	}

	void balance() {
		if(sz == 0) {
			a = (T*) malloc(initial_sz * sizeof(T));
			len = initial_sz;
		}
		else if(sz == len) {
			int nlen = len<<1;
			T *temp = (T*) malloc(nlen * sizeof(T));
			for(int i=0; i<sz; ++i) temp[i] = a[i];
			free(a);
			a = temp;
			len = nlen;
		}
		else if(sz+sz < len/2) {
			int nlen = len>>1;
			if(nlen < initial_sz) nlen = initial_sz;
			T *temp = (T*) malloc(nlen * sizeof(T));
			for(int i=0; i<sz; ++i) temp[i] = a[i];
			free(a);
			a = temp;
			len = nlen;
		}
	}
	
public:
	max_heap() {
		sz = 0, len = 0;
		balance();
	}

	max_heap(const max_heap &p) {
		sz = 0, len = 0;
		balance();
		while(sz < p.sz) {
			balance();
			a[sz] = p.a[sz];
			++sz;
		}
	}

	void push(T key) {
		balance();
		++sz;
		a[sz-1] = key;
		increase_key(sz, key);
	}

	T top() {
		if(sz > 0) return a[0];
		cerr << "Ooopsie! Heap is empty!" << "\n";
		assert(false);
	}

	void pop() {
		if(sz <= 0) {
			cerr << "Ooopsie! Heap is empty!" << "\n";
			assert(false);
		}
		T ret = a[0];
		a[0] = a[sz-1];
		--sz;
		heapify(1);
		balance();
	}

	bool empty() {
		return sz == 0;
	}

	int size() {
		return sz;
	}

	void delete_max() {
		pop();
	}

	void clear() {
		sz = 0, len = 0;
		free(a);
		a = NULL;
	}

	max_heap operator=(max_heap p) {
		sz = 0, len = 0;
		balance();
		while(sz < p.sz) {
			balance();
			a[sz] = p.a[sz];
			++sz;
		}
		return *this;
	}

	~max_heap() {
		sz = 0, len = 0;
		free(a);
	}
};

template <class T>
class Vector {
	static const int initial_sz = 2;
	T *a;
	int sz, len;

	void balance() {
		if(sz == 0) {
			a = (T*) malloc(initial_sz * sizeof(T));
			len = initial_sz;
		}
		else if(sz == len) {
			int nlen = len<<1;
			T *temp = (T*) malloc(nlen * sizeof(T));
			for(int i=0; i<sz; ++i) temp[i] = a[i];
			free(a);
			a = temp;
			len = nlen;
		}
		else if(sz+sz < len/2) {
			int nlen = len>>1;
			if(nlen < initial_sz) nlen = initial_sz;
			T *temp = (T*) malloc(nlen * sizeof(T));
			for(int i=0; i<sz; ++i) temp[i] = a[i];
			free(a);
			a = temp;
			len = nlen;
		}
	}

public:
	Vector() {
		sz = 0, len = 0;
	}

	Vector(const Vector &p) {
		sz = 0, len = 0;
		while(sz < p.sz) {
			balance();
			a[sz] = p.a[sz];
			++sz;
		}
	}

	void push_back(T key) {
		balance();
		a[sz] = key;
		++sz;
	}

	void pop_back() {
		--sz;
		balance();
	}

	int size() {
		return sz;
	}

	bool empty() {
		return sz == 0;
	}

	T front() {
		return a[0];
	}

	T back() {
		return a[sz-1];
	}

	void clear() {
		sz = 0, len = 0;
		free(a);
		a = NULL;
	}

	T operator [] (int pos) {
		return a[pos];
	}

	Vector operator = (Vector p) {
		sz = 0, len = 0;
		while(sz < p.sz) {
			balance();
			a[sz] = p.a[sz];
			++sz;
		}
		return *this;
	}

	~Vector() {
		sz = 0, len = 0;
		free(a);
	}
};

const int N = 1007;
Vector<int> g[N], c[N];
int dis[N];

void dijkstra(int n, int src) {
	const int INF = 0x3f3f3f3f;
	for(int i=1; i<=n; ++i) dis[i] = INF;
	dis[src] = 0;
	
	struct node {
		int u, d;
		node(int _u=0, int _d=0) : u(_u), d(_d) { }
		bool operator < (const node &p) const { return d > p.d; }
	};
	max_heap < node > pq;
	pq.push(node(src, 0));

	while(!pq.empty()) {
		node top = pq.top();
		pq.pop();

		int u = top.u, d = top.d;
		if(d > dis[u]) continue;

		for(int j=0; j<(int) g[u].size(); ++j) {
			int v = g[u][j], w = c[u][j];
			if(dis[v] > dis[u] + w) {
				dis[v] = dis[u] + w;
				pq.push(node(v, dis[v]));
			}
		}
	}
}

int main() {
	freopen("in", "r", stdin);
	freopen("out", "w", stdout);
	
	int n, m;
	while(cin >> n >> m) {
		for(int i=1; i<=n; ++i) g[i].clear(), c[i].clear();
		
		for(int i=0; i<m; ++i) {
			int u, v, w;
			cin >> u >> v >> w;
			g[u].push_back(v);
			c[u].push_back(w);
		}

		int src;
		cin >> src;
		dijkstra(n, src);
		for(int i=1; i<=n; ++i) {
			cout << "Distance of " << i << " from " << src << ": " << dis[i] << "\n";
		}
	}

	return 0;
}